(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"InfografíaFijaNo8_atlas_", frames: [[0,1180,2048,782],[0,0,1406,1178]]},
		{name:"InfografíaFijaNo8_atlas_2", frames: [[0,1414,2048,290],[1771,252,18,2],[1534,319,18,2],[1920,484,45,28],[1633,335,67,48],[1921,129,127,127],[1504,464,81,81],[1800,484,63,48],[1600,206,127,127],[1408,478,78,81],[1729,252,19,2],[1750,252,19,2],[1513,327,6,2],[1560,323,10,2],[1573,319,13,2],[1572,323,8,2],[1554,319,17,2],[1504,327,7,2],[1715,199,12,2],[1865,484,53,53],[1858,258,127,127],[0,1044,2048,368],[1735,484,63,63],[1504,335,127,127],[1588,319,2,11],[1592,319,2,11],[1534,323,11,2],[1547,323,11,2],[1702,335,17,17],[1702,354,17,17],[1792,129,127,127],[1696,186,17,17],[1667,484,66,66],[1729,258,127,127],[1721,335,4,21],[1987,258,49,66],[1921,0,127,127],[1987,326,56,56],[1582,323,2,2],[1596,323,2,2],[1596,319,2,2],[2021,384,7,25],[2038,294,7,28],[2030,384,7,20],[2038,258,7,34],[0,1706,1314,138],[0,1846,1114,88],[0,0,1406,1042],[1504,319,8,6],[1792,0,127,127],[1587,484,78,81],[1729,186,58,64],[1967,484,34,34],[1715,186,11,11],[1696,0,94,184],[1408,0,94,476],[1504,0,94,317],[1600,0,94,204],[1514,319,8,6],[1730,387,95,95],[1924,387,95,95],[1633,387,95,95],[1827,387,95,95],[1524,319,8,6]]}
];


// symbols:



(lib.CachedTexturedBitmap_1 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_10 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_11 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_12 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_13 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_14 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_15 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_16 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_17 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_18 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_19 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_2 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_20 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_21 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_22 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_23 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_24 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_25 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_26 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_27 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_28 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_29 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_3 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_31 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_32 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_34 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_35 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_36 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_37 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_38 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_39 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_4 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_40 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_41 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_42 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_44 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_45 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_46 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_48 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_49 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_50 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_51 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_52 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_53 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_54 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_55 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_56 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_57 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_58 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_59 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_6 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_60 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_61 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_62 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_63 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_64 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_65 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_66 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_67 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_68 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_7 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_70 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_71 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_74 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_76 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_8 = function() {
	this.initialize(ss["InfografíaFijaNo8_atlas_2"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol32, new cjs.Rectangle(0,0,47.5,47.5), null);


(lib.Symbol31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_76();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31, new cjs.Rectangle(0,0,47.5,47.5), null);


(lib.Symbol30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_74();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol30, new cjs.Rectangle(0,0,47.5,47.5), null);


(lib.Symbol29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_74();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29, new cjs.Rectangle(0,0,47.5,47.5), null);


(lib.Symbol28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_74();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol28, new cjs.Rectangle(0,0,47.5,47.5), null);


(lib.Symbol27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_71();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol27, new cjs.Rectangle(0,0,47.5,47.5), null);


(lib.Symbol26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_70();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26, new cjs.Rectangle(0,0,47.5,47.5), null);


(lib.Symbol25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_70();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol25, new cjs.Rectangle(0,0,47.5,47.5), null);


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_68();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,47,102);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_67();
	this.instance.parent = this;
	this.instance.setTransform(29.9,39.65,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_66();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,76.9,238);


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_65();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,47,92);


(lib.Symbol18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_59();
	this.instance.parent = this;
	this.instance.setTransform(0.1,68.35,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_58();
	this.instance_1.parent = this;
	this.instance_1.setTransform(153.25,545.15,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_57();
	this.instance_2.parent = this;
	this.instance_2.setTransform(46.05,0.1,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_56();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18, new cjs.Rectangle(0,0,710.3,589.4), null);


(lib.Path_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_3();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2, new cjs.Rectangle(0,0,1024,184), null);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(0,0,1024,391), null);


(lib.Path = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,1024,145), null);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_64();
	this.instance.parent = this;
	this.instance.setTransform(30.25,26.3,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_63();
	this.instance_1.parent = this;
	this.instance_1.setTransform(24.6,20.65,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_62();
	this.instance_2.parent = this;
	this.instance_2.setTransform(17.05,15.75,0.5,0.5);

	this.instance_3 = new lib.Symbol30();
	this.instance_3.parent = this;
	this.instance_3.setTransform(31.65,31.6,1,1,0,0,0,23.7,23.7);
	this.instance_3.shadow = new cjs.Shadow("rgba(68,68,68,1)",3,3,5);

	this.instance_4 = new lib.CachedTexturedBitmap_61();
	this.instance_4.parent = this;
	this.instance_4.setTransform(7.95,7.9,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_60();
	this.instance_5.parent = this;
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol21, new cjs.Rectangle(0,0,68,67.9), null);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_55();
	this.instance.parent = this;
	this.instance.setTransform(27.6,25.15,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_54();
	this.instance_1.parent = this;
	this.instance_1.setTransform(33.2,32.1,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_53();
	this.instance_2.parent = this;
	this.instance_2.setTransform(38.8,28.15,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_52();
	this.instance_3.parent = this;
	this.instance_3.setTransform(22.05,29.9,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_51();
	this.instance_4.parent = this;
	this.instance_4.setTransform(37.85,19.8,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_50();
	this.instance_5.parent = this;
	this.instance_5.setTransform(40.2,19.8,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_49();
	this.instance_6.parent = this;
	this.instance_6.setTransform(42.5,19.8,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_48();
	this.instance_7.parent = this;
	this.instance_7.setTransform(17.75,17.7,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_61();
	this.instance_8.parent = this;
	this.instance_8.setTransform(7.95,7.9,0.5,0.5);

	this.instance_9 = new lib.Symbol32();
	this.instance_9.parent = this;
	this.instance_9.setTransform(31.65,31.6,1,1,0,0,0,23.7,23.7);
	this.instance_9.shadow = new cjs.Shadow("rgba(68,68,68,1)",3,3,5);

	this.instance_10 = new lib.CachedTexturedBitmap_46();
	this.instance_10.parent = this;
	this.instance_10.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16, new cjs.Rectangle(0,0,68,67.9), null);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_45();
	this.instance.parent = this;
	this.instance.setTransform(19.35,15.05,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_44();
	this.instance_1.parent = this;
	this.instance_1.setTransform(29.75,30.4,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_61();
	this.instance_2.parent = this;
	this.instance_2.setTransform(7.9,7.9,0.5,0.5);

	this.instance_3 = new lib.Symbol31();
	this.instance_3.parent = this;
	this.instance_3.setTransform(31.6,31.6,1,1,0,0,0,23.7,23.7);
	this.instance_3.shadow = new cjs.Shadow("rgba(68,68,68,1)",3,3,5);

	this.instance_4 = new lib.CachedTexturedBitmap_42();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(0,0,67.9,67.9), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_41();
	this.instance.parent = this;
	this.instance.setTransform(15.05,15,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_40();
	this.instance_1.parent = this;
	this.instance_1.setTransform(32.25,33.75,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_39();
	this.instance_2.parent = this;
	this.instance_2.setTransform(20.95,22.4,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_38();
	this.instance_3.parent = this;
	this.instance_3.setTransform(20.95,33.75,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_37();
	this.instance_4.parent = this;
	this.instance_4.setTransform(18.65,31.85,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_36();
	this.instance_5.parent = this;
	this.instance_5.setTransform(37.8,31.85,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_35();
	this.instance_6.parent = this;
	this.instance_6.setTransform(30.4,39.25,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_34();
	this.instance_7.parent = this;
	this.instance_7.setTransform(30.4,20.1,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_61();
	this.instance_8.parent = this;
	this.instance_8.setTransform(7.9,7.9,0.5,0.5);

	this.instance_9 = new lib.Symbol29();
	this.instance_9.parent = this;
	this.instance_9.setTransform(31.6,31.6,1,1,0,0,0,23.7,23.7);
	this.instance_9.shadow = new cjs.Shadow("rgba(68,68,68,1)",3,3,5);

	this.instance_10 = new lib.CachedTexturedBitmap_32();
	this.instance_10.parent = this;
	this.instance_10.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(0,0,67.9,67.9), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_31();
	this.instance.parent = this;
	this.instance.setTransform(15.8,15.85,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_61();
	this.instance_1.parent = this;
	this.instance_1.setTransform(7.95,7.9,0.5,0.5);

	this.instance_2 = new lib.Symbol28();
	this.instance_2.parent = this;
	this.instance_2.setTransform(31.65,31.6,1,1,0,0,0,23.7,23.7);
	this.instance_2.shadow = new cjs.Shadow("rgba(68,68,68,1)",3,3,5);

	this.instance_3 = new lib.CachedTexturedBitmap_29();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(0,0,68,67.9), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_28();
	this.instance.parent = this;
	this.instance.setTransform(18.3,18.3,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_27();
	this.instance_1.parent = this;
	this.instance_1.setTransform(29.85,40.6,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_26();
	this.instance_2.parent = this;
	this.instance_2.setTransform(24.8,40.6,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_25();
	this.instance_3.parent = this;
	this.instance_3.setTransform(24.8,37.55,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_24();
	this.instance_4.parent = this;
	this.instance_4.setTransform(34.45,37.55,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_23();
	this.instance_5.parent = this;
	this.instance_5.setTransform(24.8,28.3,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_22();
	this.instance_6.parent = this;
	this.instance_6.setTransform(32.5,28.3,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_21();
	this.instance_7.parent = this;
	this.instance_7.setTransform(24.8,25.25,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_20();
	this.instance_8.parent = this;
	this.instance_8.setTransform(29.2,25.25,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_19();
	this.instance_9.parent = this;
	this.instance_9.setTransform(24.8,22.15,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_18();
	this.instance_10.parent = this;
	this.instance_10.setTransform(7.9,7.9,0.5,0.5);

	this.instance_11 = new lib.Symbol27();
	this.instance_11.parent = this;
	this.instance_11.setTransform(31.6,31.6,1,1,0,0,0,23.7,23.7);
	this.instance_11.shadow = new cjs.Shadow("rgba(68,68,68,1)",3,3,5);

	this.instance_12 = new lib.CachedTexturedBitmap_17();
	this.instance_12.parent = this;
	this.instance_12.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,67.9,67.9), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_16();
	this.instance.parent = this;
	this.instance.setTransform(16,19.75,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_15();
	this.instance_1.parent = this;
	this.instance_1.setTransform(7.9,7.9,0.5,0.5);

	this.instance_2 = new lib.Symbol26();
	this.instance_2.parent = this;
	this.instance_2.setTransform(31.6,31.6,1,1,0,0,0,23.7,23.7);
	this.instance_2.shadow = new cjs.Shadow("rgba(68,68,68,1)",3,3,5);

	this.instance_3 = new lib.CachedTexturedBitmap_14();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,67.9,67.9), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_13();
	this.instance.parent = this;
	this.instance.setTransform(13.75,19.05,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(19.15,21.25,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(28.1,31.35,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_10();
	this.instance_3.parent = this;
	this.instance_3.setTransform(28.1,27.65,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_11();
	this.instance_4.parent = this;
	this.instance_4.setTransform(28.1,23.95,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_8();
	this.instance_5.parent = this;
	this.instance_5.setTransform(22.6,30.3,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(22.6,26.55,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_6();
	this.instance_7.parent = this;
	this.instance_7.setTransform(22.6,22.9,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_15();
	this.instance_8.parent = this;
	this.instance_8.setTransform(7.9,7.9,0.5,0.5);

	this.instance_9 = new lib.Symbol25();
	this.instance_9.parent = this;
	this.instance_9.setTransform(31.6,31.6,1,1,0,0,0,23.7,23.7);
	this.instance_9.shadow = new cjs.Shadow("rgba(68,68,68,1)",3,3,5);

	this.instance_10 = new lib.CachedTexturedBitmap_4();
	this.instance_10.parent = this;
	this.instance_10.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,67.9,67.9), null);


// stage content:
(lib.InfografíaFijaNo8 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_76 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(76).call(this.frame_76).wait(1));

	// Symbol_16
	this.instance = new lib.Symbol16();
	this.instance.parent = this;
	this.instance.setTransform(586.3,631.8,0.2,0.2,0,0,0,31.8,31.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(58).to({_off:false},0).to({regX:31.6,regY:31.6,scaleX:1,scaleY:1},15,cjs.Ease.backOut).wait(4));

	// Symbol_13
	this.instance_1 = new lib.Symbol13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(289.65,631.8,0.2,0.2,0,0,0,31.8,31.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50).to({_off:false},0).to({regX:31.6,regY:31.6,scaleX:1,scaleY:1},18,cjs.Ease.backOut).wait(9));

	// Layer_10
	this.instance_2 = new lib.Symbol21();
	this.instance_2.parent = this;
	this.instance_2.setTransform(155.1,442.25,0.2,0.2,0,0,0,31.8,31.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(37).to({_off:false},0).to({regX:31.6,regY:31.6,scaleX:1,scaleY:1},21,cjs.Ease.backOut).wait(19));

	// Symbol_9
	this.instance_3 = new lib.Symbol9();
	this.instance_3.parent = this;
	this.instance_3.setTransform(408.6,361.4,0.2,0.2,0,0,0,31.8,31.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(32).to({_off:false},0).to({regX:31.6,regY:31.6,scaleX:1,scaleY:1},18,cjs.Ease.backOut).wait(27));

	// Symbol_7
	this.instance_4 = new lib.Symbol7();
	this.instance_4.parent = this;
	this.instance_4.setTransform(752.8,361.4,0.2,0.2,0,0,0,31.8,31.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(23).to({_off:false},0).to({regX:31.7,regY:31.6,scaleX:1,scaleY:1,x:752.85},21,cjs.Ease.backOut).wait(33));

	// Symbol_5
	this.instance_5 = new lib.Symbol5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(808.7,141.9,0.2,0.2,0,0,0,31.8,31.8);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(12).to({_off:false},0).to({regX:31.6,regY:31.6,scaleX:1,scaleY:1},18,cjs.Ease.backOut).wait(47));

	// Symbol_4
	this.instance_6 = new lib.Symbol4();
	this.instance_6.parent = this;
	this.instance_6.setTransform(522.35,86.9,0.2,0.2,0,0,0,31.8,31.8);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(7).to({_off:false},0).to({regX:31.6,regY:31.6,scaleX:1,scaleY:1},15,cjs.Ease.backOut).wait(55));

	// Symbol_2
	this.instance_7 = new lib.Symbol2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(188.45,86.9,0.2,0.2,0,0,0,31.8,31.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({regX:31.6,regY:31.6,scaleX:1,scaleY:1},18,cjs.Ease.backOut).wait(59));

	// Layer_22 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_48 = new cjs.Graphics().p("AisG8IAAt3IFZAAIAAN3g");
	var mask_graphics_49 = new cjs.Graphics().p("AnAG8IAAt3IOBAAIAAN3g");
	var mask_graphics_50 = new cjs.Graphics().p("ArVG8IAAt3IWrAAIAAN3g");
	var mask_graphics_51 = new cjs.Graphics().p("AvpG8IAAt3IfTAAIAAN3g");
	var mask_graphics_52 = new cjs.Graphics().p("Az+G8IAAt3MAn9AAAIAAN3g");
	var mask_graphics_53 = new cjs.Graphics().p("A4TG8IAAt3MAwnAAAIAAN3g");
	var mask_graphics_54 = new cjs.Graphics().p("A8nG8IAAt3MA5PAAAIAAN3g");
	var mask_graphics_55 = new cjs.Graphics().p("Egg8AG8IAAt3MBB5AAAIAAN3g");
	var mask_graphics_56 = new cjs.Graphics().p("EglQAG8IAAt3MBKhAAAIAAN3g");
	var mask_graphics_57 = new cjs.Graphics().p("EgplAG8IAAt3MBTLAAAIAAN3g");
	var mask_graphics_58 = new cjs.Graphics().p("Egt6AG8IAAt3MBb0AAAIAAN3g");
	var mask_graphics_59 = new cjs.Graphics().p("EgyOAG8IAAt3MBkdAAAIAAN3g");
	var mask_graphics_60 = new cjs.Graphics().p("Eg2jAG8IAAt3MBtHAAAIAAN3g");
	var mask_graphics_61 = new cjs.Graphics().p("Eg63AG8IAAt3MB1vAAAIAAN3g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(48).to({graphics:mask_graphics_48,x:116.45,y:622.625}).wait(1).to({graphics:mask_graphics_49,x:144.1,y:622.625}).wait(1).to({graphics:mask_graphics_50,x:171.775,y:622.625}).wait(1).to({graphics:mask_graphics_51,x:199.425,y:622.625}).wait(1).to({graphics:mask_graphics_52,x:227.1,y:622.625}).wait(1).to({graphics:mask_graphics_53,x:254.75,y:622.625}).wait(1).to({graphics:mask_graphics_54,x:282.4,y:622.625}).wait(1).to({graphics:mask_graphics_55,x:310.075,y:622.625}).wait(1).to({graphics:mask_graphics_56,x:337.725,y:622.625}).wait(1).to({graphics:mask_graphics_57,x:365.375,y:622.625}).wait(1).to({graphics:mask_graphics_58,x:393.05,y:622.625}).wait(1).to({graphics:mask_graphics_59,x:420.7,y:622.625}).wait(1).to({graphics:mask_graphics_60,x:448.375,y:622.625}).wait(1).to({graphics:mask_graphics_61,x:476.025,y:622.625}).wait(16));

	// Layer_21
	this.instance_8 = new lib.Symbol18();
	this.instance_8.parent = this;
	this.instance_8.setTransform(485.3,360.35,1,1,0,0,0,351.6,294.6);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(48).to({_off:false},0).wait(29));

	// Layer_20 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_22 = new cjs.Graphics().p("AisG8IAAt3IFZAAIAAN3g");
	var mask_1_graphics_23 = new cjs.Graphics().p("AnCG8IAAt3IOFAAIAAN3g");
	var mask_1_graphics_24 = new cjs.Graphics().p("AraG8IAAt3IW1AAIAAN3g");
	var mask_1_graphics_25 = new cjs.Graphics().p("AvwG8IAAt3IfhAAIAAN3g");
	var mask_1_graphics_26 = new cjs.Graphics().p("A0HG8IAAt3MAoPAAAIAAN3g");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4eG8IAAt3MAw9AAAIAAN3g");
	var mask_1_graphics_28 = new cjs.Graphics().p("A81G8IAAt3MA5rAAAIAAN3g");
	var mask_1_graphics_29 = new cjs.Graphics().p("EghMAG8IAAt3MBCZAAAIAAN3g");
	var mask_1_graphics_30 = new cjs.Graphics().p("EglkAG8IAAt3MBLJAAAIAAN3g");
	var mask_1_graphics_31 = new cjs.Graphics().p("Egp6AG8IAAt3MBT1AAAIAAN3g");
	var mask_1_graphics_32 = new cjs.Graphics().p("EguRAG8IAAt3MBcjAAAIAAN3g");
	var mask_1_graphics_33 = new cjs.Graphics().p("EgyoAG8IAAt3MBlRAAAIAAN3g");
	var mask_1_graphics_34 = new cjs.Graphics().p("Eg2/AG8IAAt3MBt/AAAIAAN3g");
	var mask_1_graphics_35 = new cjs.Graphics().p("Eg7WAG8IAAt3MB2tAAAIAAN3g");
	var mask_1_graphics_36 = new cjs.Graphics().p("Eg7WAIMIAAwXMB2tAAAIAAQXg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Eg7WAJcIAAy3MB2tAAAIAAS3g");
	var mask_1_graphics_38 = new cjs.Graphics().p("Eg7WAKtIAA1YMB2tAAAIAAVYg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Eg7WAL9IAA34MB2tAAAIAAX4g");
	var mask_1_graphics_40 = new cjs.Graphics().p("Eg7WANNIAA6ZMB2tAAAIAAaZg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Eg7WAOdIAA85MB2tAAAIAAc5g");
	var mask_1_graphics_42 = new cjs.Graphics().p("Eg7WAPtIAA/ZMB2tAAAIAAfZg");
	var mask_1_graphics_43 = new cjs.Graphics().p("Eg7WAQ9MAAAgh5MB2tAAAMAAAAh5g");
	var mask_1_graphics_44 = new cjs.Graphics().p("Eg7WASNMAAAgkZMB2tAAAMAAAAkZg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Eg7WATdMAAAgm5MB2tAAAMAAAAm5g");
	var mask_1_graphics_46 = new cjs.Graphics().p("Eg7WAUtMAAAgpZMB2tAAAMAAAApZg");
	var mask_1_graphics_47 = new cjs.Graphics().p("Eg7WAV9MAAAgr5MB2tAAAMAAAAr5g");
	var mask_1_graphics_48 = new cjs.Graphics().p("Eg7WAXNMAAAguZMB2tAAAMAAAAuZg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_1_graphics_22,x:854.1,y:354.725}).wait(1).to({graphics:mask_1_graphics_23,x:826.7,y:354.725}).wait(1).to({graphics:mask_1_graphics_24,x:799.3,y:354.725}).wait(1).to({graphics:mask_1_graphics_25,x:771.9,y:354.725}).wait(1).to({graphics:mask_1_graphics_26,x:744.525,y:354.725}).wait(1).to({graphics:mask_1_graphics_27,x:717.125,y:354.725}).wait(1).to({graphics:mask_1_graphics_28,x:689.725,y:354.725}).wait(1).to({graphics:mask_1_graphics_29,x:662.35,y:354.725}).wait(1).to({graphics:mask_1_graphics_30,x:634.95,y:354.725}).wait(1).to({graphics:mask_1_graphics_31,x:607.55,y:354.725}).wait(1).to({graphics:mask_1_graphics_32,x:580.175,y:354.725}).wait(1).to({graphics:mask_1_graphics_33,x:552.775,y:354.725}).wait(1).to({graphics:mask_1_graphics_34,x:525.375,y:354.725}).wait(1).to({graphics:mask_1_graphics_35,x:497.975,y:354.725}).wait(1).to({graphics:mask_1_graphics_36,x:497.975,y:362.725}).wait(1).to({graphics:mask_1_graphics_37,x:497.975,y:370.75}).wait(1).to({graphics:mask_1_graphics_38,x:497.975,y:378.75}).wait(1).to({graphics:mask_1_graphics_39,x:497.975,y:386.75}).wait(1).to({graphics:mask_1_graphics_40,x:497.975,y:394.775}).wait(1).to({graphics:mask_1_graphics_41,x:497.975,y:402.775}).wait(1).to({graphics:mask_1_graphics_42,x:497.975,y:410.775}).wait(1).to({graphics:mask_1_graphics_43,x:497.975,y:418.775}).wait(1).to({graphics:mask_1_graphics_44,x:497.975,y:426.8}).wait(1).to({graphics:mask_1_graphics_45,x:497.975,y:434.8}).wait(1).to({graphics:mask_1_graphics_46,x:497.975,y:442.8}).wait(1).to({graphics:mask_1_graphics_47,x:497.975,y:450.825}).wait(1).to({graphics:mask_1_graphics_48,x:497.975,y:458.825}).wait(29));

	// Layer_18
	this.instance_9 = new lib.Symbol18();
	this.instance_9.parent = this;
	this.instance_9.setTransform(485.3,360.35,1,1,0,0,0,351.6,294.6);
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(22).to({_off:false},0).wait(55));

	// Layer_19 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AisG8IAAt3IFYAAIAAN3g");
	var mask_2_graphics_1 = new cjs.Graphics().p("AnOG8IAAt3IOdAAIAAN3g");
	var mask_2_graphics_2 = new cjs.Graphics().p("ArxG8IAAt3IXjAAIAAN3g");
	var mask_2_graphics_3 = new cjs.Graphics().p("AwUG8IAAt3MAgoAAAIAAN3g");
	var mask_2_graphics_4 = new cjs.Graphics().p("A02G8IAAt3MAptAAAIAAN3g");
	var mask_2_graphics_5 = new cjs.Graphics().p("A5ZG8IAAt3MAyzAAAIAAN3g");
	var mask_2_graphics_6 = new cjs.Graphics().p("A97G8IAAt3MA74AAAIAAN3g");
	var mask_2_graphics_7 = new cjs.Graphics().p("EgieAG8IAAt3MBE9AAAIAAN3g");
	var mask_2_graphics_8 = new cjs.Graphics().p("EgnBAG8IAAt3MBODAAAIAAN3g");
	var mask_2_graphics_9 = new cjs.Graphics().p("EgrjAG8IAAt3MBXHAAAIAAN3g");
	var mask_2_graphics_10 = new cjs.Graphics().p("EgwGAG8IAAt3MBgNAAAIAAN3g");
	var mask_2_graphics_11 = new cjs.Graphics().p("Eg0pAG8IAAt3MBpTAAAIAAN3g");
	var mask_2_graphics_12 = new cjs.Graphics().p("Eg5LAG8IAAt3MByXAAAIAAN3g");
	var mask_2_graphics_13 = new cjs.Graphics().p("Eg5LAIhIAAxBMByXAAAIAARBg");
	var mask_2_graphics_14 = new cjs.Graphics().p("Eg5LAKGIAA0LMByXAAAIAAULg");
	var mask_2_graphics_15 = new cjs.Graphics().p("Eg5LALrIAA3VMByXAAAIAAXVg");
	var mask_2_graphics_16 = new cjs.Graphics().p("Eg5LANQIAA6eMByXAAAIAAaeg");
	var mask_2_graphics_17 = new cjs.Graphics().p("Eg5LAO0IAA9nMByXAAAIAAdng");
	var mask_2_graphics_18 = new cjs.Graphics().p("Eg5LAQZMAAAggxMByXAAAMAAAAgxg");
	var mask_2_graphics_19 = new cjs.Graphics().p("Eg5LAR+MAAAgj7MByXAAAMAAAAj7g");
	var mask_2_graphics_20 = new cjs.Graphics().p("Eg5LATiMAAAgnEMByXAAAMAAAAnEg");
	var mask_2_graphics_21 = new cjs.Graphics().p("Eg5LAVIMAAAgqPMByXAAAMAAAAqPg");
	var mask_2_graphics_22 = new cjs.Graphics().p("Eg5LAWsMAAAgtXMByXAAAMAAAAtXg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:143.25,y:88.225}).wait(1).to({graphics:mask_2_graphics_1,x:172.325,y:88.225}).wait(1).to({graphics:mask_2_graphics_2,x:201.375,y:88.225}).wait(1).to({graphics:mask_2_graphics_3,x:230.45,y:88.225}).wait(1).to({graphics:mask_2_graphics_4,x:259.5,y:88.225}).wait(1).to({graphics:mask_2_graphics_5,x:288.575,y:88.225}).wait(1).to({graphics:mask_2_graphics_6,x:317.65,y:88.225}).wait(1).to({graphics:mask_2_graphics_7,x:346.7,y:88.225}).wait(1).to({graphics:mask_2_graphics_8,x:375.775,y:88.225}).wait(1).to({graphics:mask_2_graphics_9,x:404.825,y:88.225}).wait(1).to({graphics:mask_2_graphics_10,x:433.9,y:88.225}).wait(1).to({graphics:mask_2_graphics_11,x:462.95,y:88.225}).wait(1).to({graphics:mask_2_graphics_12,x:492.025,y:88.225}).wait(1).to({graphics:mask_2_graphics_13,x:492.025,y:98.3}).wait(1).to({graphics:mask_2_graphics_14,x:492.025,y:108.4}).wait(1).to({graphics:mask_2_graphics_15,x:492.025,y:118.475}).wait(1).to({graphics:mask_2_graphics_16,x:492.025,y:128.55}).wait(1).to({graphics:mask_2_graphics_17,x:492.025,y:138.675}).wait(1).to({graphics:mask_2_graphics_18,x:492.025,y:148.75}).wait(1).to({graphics:mask_2_graphics_19,x:492.025,y:158.825}).wait(1).to({graphics:mask_2_graphics_20,x:492.025,y:168.9}).wait(1).to({graphics:mask_2_graphics_21,x:492.025,y:179}).wait(1).to({graphics:mask_2_graphics_22,x:492.025,y:189.075}).wait(55));

	// Symbol_18
	this.instance_10 = new lib.Symbol18();
	this.instance_10.parent = this;
	this.instance_10.setTransform(485.3,360.35,1,1,0,0,0,351.6,294.6);

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(77));

	// Layer_27
	this.instance_11 = new lib.Symbol24();
	this.instance_11.parent = this;
	this.instance_11.setTransform(45.7,646.7,1,1,0,0,0,23.6,51.1);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;
	new cjs.ButtonHelper(this.instance_11, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(48).to({_off:false},0).to({alpha:1},13).wait(16));

	// _Path_
	this.instance_12 = new lib.Path();
	this.instance_12.parent = this;
	this.instance_12.setTransform(512,647.4,1,1,0,0,0,512,72.5);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(48).to({_off:false},0).to({alpha:0.3984},13).wait(16));

	// Layer_26
	this.instance_13 = new lib.Symbol23();
	this.instance_13.parent = this;
	this.instance_13.setTransform(60.7,384.7,1,1,0,0,0,38.6,118.9);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;
	new cjs.ButtonHelper(this.instance_13, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(27).to({_off:false},0).to({alpha:1},18).wait(32));

	// _Path__1
	this.instance_14 = new lib.Path_1();
	this.instance_14.parent = this;
	this.instance_14.setTransform(512,379.4,1,1,0,0,0,512,195.5);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(27).to({_off:false},0).to({alpha:0.3984},18).wait(32));

	// Layer_25
	this.instance_15 = new lib.Symbol22();
	this.instance_15.parent = this;
	this.instance_15.setTransform(45.7,87.75,1,1,0,0,0,23.6,46.1);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;
	new cjs.ButtonHelper(this.instance_15, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(9).to({_off:false},0).to({alpha:1},13).wait(55));

	// _Path__2
	this.instance_16 = new lib.Path_2();
	this.instance_16.parent = this;
	this.instance_16.setTransform(512,91.9,1,1,0,0,0,512,91.9);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(9).to({_off:false},0).to({alpha:0.3984},13).wait(55));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(512,360,512,359.9);
// library properties:
lib.properties = {
	id: '8A101A3B4A05CC4BADABC6AFD7325767',
	width: 1024,
	height: 720,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/InfografíaFijaNo8_atlas_.png", id:"InfografíaFijaNo8_atlas_"},
		{src:"images/InfografíaFijaNo8_atlas_2.png", id:"InfografíaFijaNo8_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8A101A3B4A05CC4BADABC6AFD7325767'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;